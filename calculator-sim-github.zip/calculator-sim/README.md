# Calculator Sim

Mobiler Import-Kalkulator für Sport Equipment — optimiert für iPhone & Android.

## Features

- **HS-Code Lookup** — interaktive TARIC-Datenbank mit EU-Zollsätzen
- **Incoterm-Automatik** — FOB / Frei Haus / EXW mit automatischen Frachtkosten je Route
- **Live-Simulation** — UVP & Händlerrabatt per Slider oder Direkteingabe, alle Margen in Echtzeit
- **Farbskala** — rot bis hellgrün für deine Marge und Händler-Aufschlag
- **Artikelliste** — Kalkulationen speichern, verwalten und als CSV exportieren
- **Offline-fähig** — läuft komplett im Browser, kein Server nötig
- **PWA-ready** — als App auf dem Homescreen installierbar (iOS Safari & Android Chrome)

## Live-URL

> Nach Deployment via GitHub Pages:
> `https://DEIN-USERNAME.github.io/calculator-sim`

## Deployment

### Option 1 — GitHub Pages (empfohlen)

1. Repository auf GitHub erstellen
2. Alle Dateien hochladen
3. **Settings** → **Pages** → Branch: `main` → Ordner: `/ (root)` → **Save**
4. URL: `https://DEIN-USERNAME.github.io/calculator-sim`

### Option 2 — Netlify Drop

1. [drop.netlify.com](https://drop.netlify.com) öffnen
2. Den Ordner `calculator-sim` reinziehen
3. Sofort online

## Als App installieren (iPhone)

1. URL in **Safari** öffnen
2. Teilen-Symbol → **"Zum Home-Bildschirm"**
3. Fertig — App-Icon auf dem Homescreen

## Struktur

```
calculator-sim/
├── index.html          # Haupt-App (alles in einer Datei)
├── _headers            # Netlify Content-Type Header
├── .nojekyll           # GitHub Pages: kein Jekyll-Processing
└── README.md           # Diese Datei
```

## Technologie

- Vanilla HTML / CSS / JavaScript — keine Abhängigkeiten
- localStorage für persistente Datenspeicherung
- EU TARIC Zolldatenbank (eingebettet, Stand 2026)
- Routen-Datenbank FCL 20ft für 10 Abgangshäfen × 4 EU-Zielhäfen

## Daten aktualisieren

**Wechselkurs** — direkt in der App über das ✎-Symbol im Header anpassbar.

**HS-Codes / Zollsätze** — in `index.html` im Array `ZD` ergänzen:
```javascript
{c:'9506.91.00', d:'Fitnessgeräte allgemein', r:2.7},
// c = HS-Code, d = Beschreibung, r = EU-Zollsatz in %
```

**Frachtkosten** — im Objekt `RD` pro Route anpassen:
```javascript
CNSHA: { DEHAM: { f: 12, e: 4, t: 'ca. 28 Tage' } }
// f = FOB-Frachtanteil %, e = EXW-Aufschlag %, t = Transitzeit
```

---

*Calculator Sim · Sport Equipment Import*
